Week 3: Water quality parameters

This directory contains files to work with weekly water quality measurements from North Campus Open Space.

This directory contains two folders:

- code: all .qmd files for wrangling and visualization
- data: all data files

Within the `code` folder, there are two files:

- week-03_class-key.qmd: all code and responses written out
- week-03_class-template.qmd: template for in-class work on Monday and Wednesday

Within the `data` folder, there are three files:

- NCOS_YSI_Water_Quality_Monitoring_0.csv: water quality survey metadata
- NOAA-weather-data.csv: daily weather data from NOAA station at Coal Oil Point
- YSI_Data_Begin_1.csv: water quality measurements

Files are referenced using the `here` package, which we will install at the beginning of class!