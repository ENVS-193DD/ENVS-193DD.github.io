Week 2: Bird species at NCOS

This directory contains files to work with monthly bird survey data from North Campus Open Space.

This directory contains three .qmd files:

- class-template.qmd: this is the file that we'll be working with in class.
- key.qmd: this is the file with all the code pre-written. Use this when you get lost in class to copy-paste code that you may have missed.
- individual-assignment-template.qmd: this is the template for your second individual assignment. Use this when you are ready to start your homework. Note: this is the last template you will receive for your assignments.

The directory also contains a data file:

- birds.csv: This contains monthly bird survey observations from 2018 to 2025.

In class, we will create additional files:

- test.qmd and its associated files when rendered: we will test out creating a .qmd file and "rendering" it to .html and .pdf formats.
- key.pdf: we will also test out rendering with the key to see what our final template should look like.
- class-template.pdf: we will test out rendering early and often with our template script to make sure it actually renders.